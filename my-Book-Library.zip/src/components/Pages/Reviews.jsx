import NavBar from '../NavBar'
import Footer from '../Footer'

const Reviews = () => {

  return (
    <>
    <NavBar />
    <div className="container">
      <div className='flex'>
        <div className='flex'>
      <h1 className=' section-title flex '>Books Reviews</h1>
      </div>
    <div className='flex flex-col'>

    </div>
    </div>
    </div>
    <Footer />
  </>
  )
}



export default Reviews

