import { Link } from 'react-router-dom'

const Books_showcase = () => {
  return (
    <div className='container flex flex-col p-10 mx-auto px-4 w-full '>
    <div className='section-title relative'>
    <h2 className='text-[var(--main-fo-cl)] '>Books </h2>
    </div>
    <div className="mt-32 lg:absolute lg:top-10  justify-center md:justify-center">
      <Link to="/bookList">
          <button className="bg-[var(--sec-bg-cl)] text-white font-bold text-xs py-2 px-4 rounded-md">Browse All Books</button>
      </Link>
      </div>
        </div>
  )
}

export default Books_showcase