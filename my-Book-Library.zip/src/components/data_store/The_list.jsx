import { useEffect, useState } from "react";
import NavBar from "../NavBar";
import Footer from "../Footer";

const The_list = () => {
  const [books_data, setBooks_data] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/books_data")
      .then((response) => response.json())
      .then((data) => setBooks_data(data))
      .catch((error) => console.error("Error fetching books_data:", error));
  }, []);

  return (
    <>
      <NavBar />
      <div className="container">
        <h1 className="section-title flex">Books_data List</h1>
        <div className="grid grid-cols-4 gap-4">
          {books_data.map((books_data) => (
            <div key={books_data.id} className="book-card">
              <img src={books_data.cover} alt={books_data.title} className="book-cover" />
              <h2 className="book-title">{books_data.title}</h2>
              <p className="book-author">By: {books_data.author}</p>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </>
  );
};

export default The_list;
