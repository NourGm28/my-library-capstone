
const ReviewsData = ({ reviews }) => {
    return (
      <div className="reviews">
        <h2>Reviews</h2>
        {reviews.length > 0 ? (
          reviews.map((review, index) => (
            <div key={index} className="review-item">
              <h3>{review.reviewer}</h3>
              <p>{review.comment}</p>
              <p>Rating: {review.rating} / 5</p>
            </div>
          ))
        ) : (
          <p>No reviews yet.</p>
        )}
      </div>
    );
  };
  
  export default ReviewsData;
  