import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import NavBar from "../NavBar";
import Footer from "../Footer";

const BookDetails = () => {
  const { id } = useParams();
  const [books_data, setBooks_data] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:5000/Books_data/${id}`)
      .then((response) => response.json())
      .then((data) => setBooks_data(data))
      .catch((error) => console.error("Error fetching book details:", error));
  }, [id]);

  if (!books_data) {
    return <div>Loading...</div>;
  }

  return (
    <>
      <NavBar />
      <div className="container">
        <h1 className="section-title">{books_data.title}</h1>
        <div className="flex">
          <img src={books_data.cover} alt={books_data.title} className="book-cover-lg" />
          <div className="book-details">
            <p><strong>Author:</strong> {books_data.author}</p>
            <p><strong>Publication:</strong> {books_data.publication}</p>
            <p><strong>Publication Date:</strong> {books_data.publicationDate}</p>
            <p><strong>ISBN:</strong> {books_data.isbn}</p>
            <p><strong>Pages:</strong> {books_data.pages}</p>
            <p><strong>Subjects:</strong> {books_data.subjects.join(", ")}</p>
            <p>{books_data.description}</p>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default BookDetails;
