import React from 'react'
import NavBar from '../components/NavBar'
import SearchForm from './SearchForm'
import Footer from './Footer'

const BookList = () => {

  return (
    <>
    <NavBar />
    <div className="container mx-auto px-4">
        <div>
        <div className='flex items-center justify-center'>
      <h1 className=' section-title absolute flex justify-center text-center '>All Books List</h1>
      </div>
      <SearchForm/>
      </div>
      <div>

      </div>
    </div>
    <Footer />
  </>
  )
}

export default BookList  
