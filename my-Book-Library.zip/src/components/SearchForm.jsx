import {useRef, useEffect} from 'react'
import { FaSearch } from "react-icons/fa";
import { useNavigate } from 'react-router-dom'

const SearchForm = () => {
    
  return (
    <>
      <div className='flex justify-center w-full'>
          <form onSubmit={handleSubmit}>
            <div className=' flex items-center justify-center'>
              <input type = "text" className='w-full p-2  outline-none  border-[1px] border-blue-700 rounded-full' placeholder='SEARCH' ref = {searchText} />
              <button type = "submit" className='p-2' >
                <FaSearch className='text-[var(--sec-bg-cl)]' size = {32} />
              </button>
            </div>
          </form>
      </div>
    </>
  )
}

export default SearchForm
