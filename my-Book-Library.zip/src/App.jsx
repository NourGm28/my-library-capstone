import { BrowserRouter, Route, Routes } from 'react-router-dom';
  import About from './components/Pages/About';
  import Categories from './components/Pages/Categories';
  import Reviews from './components/Pages/Reviews';
  import HomePage from './components/Pages/HomePage';
  import SearchForm from './components/SearchForm';
  import Header from './components/Header';
  import BookList from './components/BookList';
  import Books_showcase from './components/Pages/books_showcase';
  import Intro_Categories from './components/Pages/Intro_Categories';
  import Contact_sect from './components/Pages/Contact_sect';
  import The_list from './components/data_store/The_list';
  import BookDetails from './components/data_store/BookDetails';
  import ReviewsData from './components/data_store/ReviewsData';

import './App.css'

function App() {
  return (
      <BrowserRouter>
        <Routes>
          <Route path="/header" element={<Header />} />
          <Route path="/searchform" element={<SearchForm />} />
          <Route path="/about" element={<About />} />
          <Route path="/reviews" element={<Reviews />} />
          <Route path="BookList" element={<BookList />} />
          <Route path="/Books_showcase" element={<Books_showcase />} />
          <Route path="/intro_categories" element={<Intro_Categories />} />
          <Route path="/contact_sect" element={<Contact_sect />} />
          <Route path="/the_list" element={<The_list />} />
          <Route path="/reviewsData" element={<ReviewsData />} />
          <Route path="/the_list/:id" element={<BookDetails />} />
          <Route path="/categories" element={<Categories />} />
          <Route path="/" element={<HomePage />} />
        </Routes>
      </BrowserRouter>
    
  );
}

export default App;
